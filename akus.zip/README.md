<p align="center"><a href="#" target="_blank"><img src="https://pendasial.wstif3b.id/img/logo-sekolah.png" width="400" alt="SMK Darus Sholah"></a></p>

## About our project

Projek yang kami buat adalah aplikasi manajemen bendahara pada sekolah SMK Darus Sholah yang berlokasikan di Kota Jember, projek kami menggunakan versi laravel Framework versi 9.

Fitur-fitur yang kami sediakan pada projek kami adalah :

- Login System

## Developer Team

- Farhan Hilmy Arwanto - Project Management
- Faqih Mustafa - UI/UX Designer
- Ida Sevia - Frontend Developer
- Khairatuz Zahro - Fullstack Developer
- Moch. Iqbal Maulana Fiekri - Backend Developer