

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Data Siswa</h1>
    </div>

        <div class="card shadow col-xl-12 mr-3">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-success">Informasi Siswa</h6>
            </div>
            <div class="card-body p-3">
                <div class="row float-right">
                    <a href="<?php echo e(route('data-siswa.create')); ?>"><button class="btn btn-success mb-3 text-end mr-2"><i class="fa fa-plus mr-2"></i>Tambah data</button></a>
                </div>

                
                <div class="modal fade" id="deleteDataModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Hapus Data Kelas</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="" method="POST" id="modal-form-siswa-delete">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id_siswa" id="id_siswa">
                                    Apakah anda yakin untuk menghapus data ini?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-danger">Hapus Data</button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered" id="table_siswa" width="100%" cellspacing="0">
                        <thead>
                            <th>NISN</th>
                            <th>NIS</th>
                            <th>Nama Siswa</th>
                            <th>Jenis Kelamin</th>
                            <th>Kelas Siswa</th>
                            <th>Nomer HP</th>
                            <th>Status Pondok</th>
                            <th>Status Alumni</th>
                            <th>Nomer VA</th>
                            <th>Aksi</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->nisn); ?></td>
                                    <td><?php echo e($item->nis); ?></td>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->jenis_kelamin); ?></td>
                                    <td><?php echo e($item->data_kelas->nama_kelas); ?></td>
                                    <td><?php echo e($item->no_hp); ?></td>
                                    <td><?php echo e($item->status_pondok); ?></td>
                                    <td><?php echo e($item->status_alumni); ?></td>
                                    <td><?php echo e($item->no_va); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('data-siswa.edit', $item->nisn )); ?>"><button class="btn btn-warning"> <i class="fas fa-pen fa-sm"></i> </button></a>
                                            <button class="btn btn-danger btn-delete-modal" id="deleteButtonModal"
                                                data-nisn="<?php echo e($item->nisn); ?>"
                                            >
                                            <i class="fas fa-trash fa-sm"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-section'); ?>
    <script src="<?php echo e(asset('js/layouts/data-siswa.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\a-kus_project\resources\views/layouts/data_siswa.blade.php ENDPATH**/ ?>