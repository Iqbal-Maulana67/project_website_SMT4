$(document).ready(function (){
    $('#table_laporan_pembayaran').dataTable();
});